//sortare descrescatoare

#include <iostream>

using namespace std;



int main(){

int x;

{

cout<<"cate numere sortate doriti?"<<endl;

cin>>x;



}

int v[100];

int i;

for (i = 1; i <= x; i++)

        cin>>v[i];



int q;

do{

        q = 1;

        for (i = 1; i <= x-1; i++){

                if (v[i] < v[i+1]){

                        int z = v[i];

                        v[i] = v[i+1];

                        v[i+1] = z;

                        q = 0;

                }

        }

}while(q == 0);



for (i = 1; i <= x; i++)

        cout<<v[i]<<" ";



return 0;



}
